import { applyMiddleware, combineReducers, createStore } from "redux";
import logger from "redux-logger";
import thunk from "redux-thunk";
import cakeReducer from "./redux/cake/cakeReducer";
import icecreamReducer from "./redux/icecream/icecreamReducer";
import userReducer from "./redux/user/userReducer";

const rootReducer = combineReducers({
  cake: cakeReducer,
  icecream: icecreamReducer,
  user:userReducer,
});
const store = createStore(rootReducer, applyMiddleware(logger, thunk));

export  default store;