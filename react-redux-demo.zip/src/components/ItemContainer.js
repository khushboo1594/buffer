import React from "react";
import { connect } from "react-redux";
import { buyCake } from "../redux/cake/cakeAction";
import { buyIcecream } from "../redux/icecream/icecreamAction";

function ItemContainer(props) {
  return (
    <div>
      <h2>Item - {props.item}
      <button onClick={props.buyItem}>Buy item</button></h2>
    </div>
  );
}

const mapStateToProps = (state, ownProps) => {
  const itemState = ownProps.cake
    ? state.cake.numberOfCakes
    : state.icecream.numberOfIcecreams;

  return {
    item: itemState,
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  const dispatchFunction = ownProps.cake
    ? () => dispatch(buyCake())
    : () => dispatch(buyIcecream());

    return{
        buyItem:dispatchFunction
    }
};
// export default connect(mapStateToProps, mapDispatchToProps)(ItemContainer);
export default connect(null, mapDispatchToProps)(ItemContainer);

/*
What to do when you don't want to subscribe to the changes in the store. Simply pass null as the first argument to connect.
*/