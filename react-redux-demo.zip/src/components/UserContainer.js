import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
// import { connect } from 'react-redux'
import { fetchUsers } from "../redux/user/userActions";

function UserContainer({userData, fetchUsers}) {
  useEffect(()=>{
    fetchUsers()
  },[])
  const userdata = useSelector((state) => state.users);
  const dispatch=useDispatch(dispatch=>dispatch(fetchUsers()))
  return <div>UserContainer</div>;
}

export default UserContainer;
 