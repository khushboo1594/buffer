import { BUY_ICECREAM } from "./icecreamTypes";

export const buyIcecream = () => {
  return { type: BUY_ICECREAM };
};

