react aur redux ko join karne k liye we have react-redux 
it has something known as _provider_ 