What we are going to do?
We are going to fetch the data from an API and store it in the redux store.

What we have to learn?
    > How state would work?
    > How actions would work?
    > How reducers would work?

**_State_**
When we are fetching data we go with 3 state properties:
state:{
    loading:true,
    data=[],
    error:'',
}

_loading_: display a loading spinner in your component
_data_: list of users
_error_: diplay error to the user

**_actions_**:
FETCH_USER_REQUEST - fetch a list of users
FETCH_USER_SUCCESS - fetched successfully
FETCH_USER_FAILURE - error fetching the data

**_reducers_**:
case: FETCH_USER_REQUEST
    loading:true
case: FETCH_USER_SUCCESS
    loading:false
    data: data(from API)
case: FETCH_USER_FAILURE
    loading:false
    error: error(from API)