# React - redux pattern
Actions, reducer, store and in the end connect all of them to the component.
Components can access state and dispatch actions
React hooks were introduced so that functional components can have local state and can perform side effects.

# React-redux hooks
They provide a alternative for the connect HOC. they allow you to access the react store and dispatch actions.

# useSelector Hook
It is a equivalent of the mapStateToProps fucntion(CakeContainer.js). so to get the hold of any state we use the useSelector hook. 
it is a function. parameters:
1. a function - it is called as a selector function. this function in turn accepts _state_ as its _argument_. it can _return_ a _value_.

_The selector will be called with the entire Redux store state as its only argument. The selector will be run whenever the function component renders (unless its reference hasn't changed since a previous render of the component so that a cached result can be returned by the hook without re-running the selector). useSelector() will also subscribe to the Redux store, and run your selector whenever an action is dispatched._ 

However, there are some differences between the selectors passed to useSelector() and a mapState function:

_The selector may return any value as a result, not just an object. The return value of the selector will be used as the return value of the useSelector() hook.
When an action is dispatched, useSelector() will do a reference comparison of the previous selector result value and the current result value. If they are different, the component will be forced to re-render. If they are the same, the component will not re-render.
The selector function does not receive an ownProps argument. However, props can be used through closure (see the examples below) or by using a curried selector.
Extra care must be taken when using memoizing selectors (see examples below for more details).
useSelector() uses strict === reference equality checks by default, not shallow equality (see the following section for more details)._


# useDispatch Hook
It returns a reference of the dispatch function. 

***It may look like that using hooks is way simpler but there are some catch***