There are 2 steps:
1. add the extension to the browser
2. add the package to our application