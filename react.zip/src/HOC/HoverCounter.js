import React, { Component } from "react";
import withCounter from "./withCounter";
class HoverCounter extends Component {
  render() {
    const { count, incrementCounter } = this.props;
    return (
      <div>
        <button onMouseOver={incrementCounter}>{this.props.name} Hovered {count} times</button>{" "}
      </div>
    );
  }
}

export default withCounter(HoverCounter, 5);

