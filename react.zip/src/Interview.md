# 1. why do we need npm and node for react? (read more about it)
npm - node package manager. it is used for managing packages.

# 2. alternative of npm
yarn

# 3. can we use a component inside another component?
yes. you can. but you can use only inside the component inside which you have nested them

# 4. can we use angular and react in the same project?
yes. since react is a library it can be used with any language.

# 5. can we use jsx without react?(read more)
yes

# 6. why should we use state? why the var is not updated?
because when the variable is updated the component is not updated, but when we use state/props the component is updated and our purpose is fulfilled. jab tk state/props update nahi hoti hai tb tk data re-render nahi hota hai

# 7. can se use props of a component outside it? are they public, private or protected? (read more about it)
no. we cannot use props of a component outside it. they are public. 

# 8. can we use useState in classCompoent? if yes then how, if not then why not.
no. 

# 9. can we pass a function as prop?
yes. 

# 10. kya hum props ko jis component me receive kar rahe hai, kya hum use waha change kar skte hai?
answer hai nahi. hum prors keval waha change kar skte hai jaha hum use pass kar rahe hai. it is applicable to both class and functional component.

# 11. kya hum component me html bhi paas kar sakte hai?
yes. this.props.children -> class component. this.children -> functional compoenent 

# 12. can we get the value of checkbox and radio button just like we get the value of input box? 
yes.

# 13. can we achieve conditional rendering with let without using useState?
I think yes.  

# 14. kya super child me bhi hum 

# 15. component lifecycle me 3 phases hote hai - mount, update, unmount. agar ek component unmount ho gaya hai to kya use waps se load karne par nae lifecycle aaegi k wahi continue hogi?
nae life cycle banegi

# 16. kya hum props le sakte hai constructor me? 
> yes. pass "props" to both constructor and super. then only you can access props in constructor. you need to call super(props) method before any other statement. If you do not call super(props) method, this.props will be undefined

# 17. kya 1 function k andar 1 se jyada render method ho sakti hai? can we have nested render methods?
yes. we can have m

# 18. can we do something so that componentDidUpdate does not gets called?
yes. componentDidUpdate() will not be invoked if shouldComponentUpdate() returns false.

# 19. kya hame componentDidUpdate me API call karna chahie?
yes, you can call an API, but it should be conditional. 

# 20. pehle kya call hota hai - componentDidUpdate ya shouldComponentUpdate?
shouldComponentUpdate is called first

# 21. will componentWillUnmount called before or after  the component is removed from the DOM? 
just before

# 22. can hooks be used in class component?
no

# 23. can we use useState in useEffect?
yes, we can. although remember to call it on a condition otherwise it will result in a infinite loop.