# Definition

_Portals_ let's you access DOM node outside of the DOM hierarchy.
Har component root node k andar hota hai(see index.html, index.js). But agar we want to add something outside this we can do so by using _Portals_

# Steps:

1. add a extra node in index.html outside the root node.
2. import ReactDOM library
3. instead of just returning the JSX return ReactDOM.createPortal(JSX, getElementById()) (the id will be of the extra node that you created in the index.html file)

# Why?
