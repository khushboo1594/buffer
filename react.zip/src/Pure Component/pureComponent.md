Pure component is useful for performance optimization. It does not re-renders unnecessarily.

# regular component
a regular component does not implements should component update. it always returns true by default.

# pure component
a pure component implements should component update with shallow comparision of props and state. if here is a difference then only the component will re-render.

# shallow comparision
> for 2 primitive types:
it will return true if they have the same value and same type.

> complex types - objects, arrays
the comparision will return true only when the reference is same. 
----------------------------------------------------------------------------------------------------------------------
Always return something if you want to change something rather than changing the prop and state jo k object ho because those reference kbhi change nahi hota so it will assume it to be not changed and will not render it.
----------------------------------------------------------------------------------------------------------------------
When you have made parent component as pure component make sure to make all child components also as pure to avoid  unexpected behaviour.
When dealing with pure components never mutate the state always return a new state.
----------------------------------------------------------------------------------------------------------------------
pure components keval class me kaam karte hai. functional component k liye we have to use React.memo