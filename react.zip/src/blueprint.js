/* 

*/

import React, { Component } from "react";

export default class ComponentUpdate extends Component {
  render() {
    return (
      <div>
        <center>

        <h1></h1>
        </center>
      </div>
    );
  }
}

/* 
QUESTIONS
*/

/* 
rfce - functional component snippet
*/

import React, {} from "react";

export default function removeComponent() {
  return (
    <div>
      <center>

      <h1></h1>
      </center>
    </div>
  );
}

/* 
QUESTIONS
*/

constructor(){
  super();
  this.state={
      
  }
}