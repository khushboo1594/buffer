import React from 'react'
import {useNavigate} from 'react-router-dom';

function OrderSummary() {
    const navigate = useNavigate(); 
  return (
    <div>Order Confirmed!!!
         {/* <button onClick={() => navigate('/')}>Go back</button> */}
         <button onClick={() => navigate(-1)}>Go back</button>
    </div>
  )
}

export default OrderSummary;