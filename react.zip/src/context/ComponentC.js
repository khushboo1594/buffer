import React, { useContext } from "react";
import ComponentE from "./ComponentE";
import { UserContext } from "./AppCopy";

function ComponentC() {
  const user = useContext(UserContext);
  return (
    <div>
      <h2>ComponentC - {user}</h2>
      {/* Since we haven't wrapped Component C in Provider user is not accessible here. */}
      <ComponentE />
    </div>
  );
}

export default ComponentC;
  