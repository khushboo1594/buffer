import React from "react";
import ComponentF from "./ComponentF";
function ComponentE() {
  return (
    <div>
      <h3>ComponentE</h3>
      <ComponentF />
    </div>
  );
}

export default ComponentE;

    