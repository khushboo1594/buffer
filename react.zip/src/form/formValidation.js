// form validation itna samajah nhi aaya waps se dekhungi

import React, { useState } from "react";

export default function Validation() {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  function getFormData(e) {
    e.preventDefault();
  }
  function setUser(e) {
    if (e.target.value < 3) {
      console.log("Inavlid user");
    }
    else{

    }
  }
  return (
    <div>
      <form onSubmit={getFormData}>
        <center>
          <input
            style={{ marginTop: "20px" }}
            type="text"
            placeholder="Enter User Id"
            onChange={setUser}
          />
          <br />
          <br />
          <input type="text" placeholder="Password" onChange={setPass} />
          <br />
          <br />
          <button type="submit">Submit</button>
        </center>
      </form>
    </div>
  );
}

/*
QUESTIONS
> why we don't do form valiadtion through html in react? why use state? 
*/
