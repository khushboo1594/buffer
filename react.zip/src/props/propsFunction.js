// props are just like parameters of a function to the component.
