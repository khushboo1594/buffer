# What?
Reconciliation is a process by which react updates the Browser or real DOM.

# Concepts which it works on to do the process
1. Virtual DOM
2. Diffing algorithm

# Links
https://www.geeksforgeeks.org/reactjs-reconciliation/
