import React, { createContext, useReducer } from "react";
import ComponentC from "./ComponentC";
import ComponentB from "./ComponentB";
import ComponentA from "./ComponentA";

export const CountContext = createContext();

const initialState = 0;
const reducer = (currState, action) => {
  switch (action) {
    case "increment":
      return currState + 1;
    case "decrement":
      return currState - 1;
    case "reset":
      return initialState;
    default:
      return currState;
  }
};

function AppCopy() {
  const [count, dispatch] = useReducer(reducer, initialState);
  return (
    <CountContext.Provider value={{ countState: count, countDispatch: dispatch }}>
      <div>
        <center>
          <h1>Count - {count}</h1>
          <ComponentA />
          <ComponentB />
          <ComponentC />
        </center>
      </div>
    </CountContext.Provider>
  );
}

// We don't want to dispatch the action from the app component. 

export default AppCopy;
 

