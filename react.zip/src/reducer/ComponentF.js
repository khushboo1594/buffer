import React, { useContext } from "react";
import { CountContext } from "./AppCopy";
function ComponentF() {
  const count = useContext(CountContext);
  return (
    <div>
      Component F | Count - {count.countState}
      <button onClick={()=>count.countDispatch("increment")}>Increment</button>
      <button onClick={()=>count.countDispatch("decrement")}>Decrement</button>
      <button onClick={()=>count.countDispatch("reset")}>Reset</button>
    </div>
  );
}

export default ComponentF;
