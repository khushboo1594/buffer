import React, { useReducer } from "react";
const intitialState = {firstCounter:0, secondCounter:10};
const reducer = (currentState, action) => {
  switch (action.type) {
    case 'increment':
      return {...currentState, firstCounter:currentState.firstCounter + action.value};
      // How it is able to access firstCounter directly?
    case 'decrement':
      return {...currentState, firstCounter:currentState.firstCounter - action.value};
    case 'increment2':
      return {...currentState, secondCounter:currentState.secondCounter + action.value};
    case 'decrement2':
      return {...currentState, secondCounter:currentState.secondCounter - action.value};
    case 'reset':
      return intitialState ;
    default:
      return currentState;
  }
};
function UseReducerComplex() {
  const [count, dispatch] = useReducer(reducer, intitialState);

  return (
    <div>
      <center>
        <h1>Example of useReducer</h1>
        <h3>First Counter - {count.firstCounter}</h3>
        <h3>Second Counter - {count.secondCounter}</h3>
        <button onClick={()=>{dispatch({type:'increment', value:1})}}>Press to Increment</button>
        <button onClick={()=>{dispatch({type:'decrement', value:1})}}>Press to Decrement</button>
        <button onClick={()=>{dispatch({type:'increment', value:5})}}>Press to Increment by 5</button>
        <button onClick={()=>{dispatch({type:'decrement', value:5})}}>Press to Decrement by 5</button>
        <button onClick={()=>{dispatch({type:'increment2', value:1})}}>Press to Increment Second Counter</button>
        <button onClick={()=>{dispatch({type:'decrement2', value:1})}}>Press to Decrement Second Counter</button>
        <button onClick={()=>{dispatch({type:'reset'})}}>Press to Reset</button>
      </center>
    </div>
  );
}

export default UseReducerComplex;

// Isme dikkat ye ho rahi thi k hame multiple switch cases banane pad rahe the jabki hum kaam ek hi tarah ka karwa rahe the to, the solution for this is using multiple useReducers. 