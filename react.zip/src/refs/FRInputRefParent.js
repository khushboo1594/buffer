import React, { Component,  } from 'react'
import FRInputRef from './FRInputRef'
class FRInputRefParent extends Component {
  constructor(props) {
    super(props)
  
    this.inputRef=React.createRef();
  }
  render() {
    return (
      <div><FRInputRef ref={this.inputRef}/>
      <button>Focus Input</button></div>
    )
  }
}

export default FRInputRefParent