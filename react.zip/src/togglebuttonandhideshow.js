import React, { useState } from "react";

export default function toggle() {
  const [flag, setFlag] = useState(false);
  return (
    <div>
      {flag ? <h3>Hello</h3> : null}

      {/* 2 Buttons */}
      {/* <button onClick={() => setFlag(true)}>Show</button>
      <button onClick={() => setFlag(false)}>Hide</button> */}

      {/* Toggle Button */}
      <button onClick={() => setFlag(!flag)}>Click</button>
    </div>
  );
}
