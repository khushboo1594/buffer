import React from "react";

function Title() {
  console.log("Redering  title");
  return <div>useCallback Hook</div>;
}

export default React.memo(Title);
