import React, { Component, useState } from "react";
// useState 1 hook hai jisse hum state set kar skte hai
// import 'bootstrap/dist/css/bootstrap.min.css';

// IMPORTS /////////////////////////////////////////

import "./App.css";
import AppCopy from "./ErrorBoundary/AppCopy";
import ClickCounter from "./HOC/ClickCounter";
import HoverCounter from "./HOC/HoverCounter";
import PortalDemo from "./Portals/PortalDemo";
// import FRInputRefParent from "./refs/FRInputRefParent";
// import UseReducerComplex from "./reducer/UseReducerObject";
// import ClassComponent from './ClassComponent';
// import  Student  from "./Student";
// import StudentClass from "./StudentClass";
// import MyUseState from "./MyUseState";
// import Toggle from "./togglebuttonandhideshow";
// import Form from "./form";
// import ConditionalRendering from "./conditionalRendering";
// import ParentComponent from "./Pure Component/ParentComponent";
// import Validation from "./formValidation";
// import FunctionAsProp from "./passFunctionAsProp";
// import FunctionAsProp2 from "./passFunctionAsProp copy";
// import RenderExample from "./render";
// import ComponentMount from "./componentDidMount";
// import ComponentUpdate from "./componentDidUpdate";
// import ShouldComponentUpdate from "./shouldComponentUpdate";
// import ComponentUnmount from "./componentWillUnmount";
// import Hooks from "./hooks";
// import UseEffect from "./useEffectParent";
// import PropParent from "./propParent";
// import LifeCycle from "./lifeCycleMethods";
// import UseEffect from "./useEffectAsDiffLifeCycleMethods";
// import MyBootStrap from "./bootstrapExample";
// import ReactRouter from './reactRouter';
// import AppCopy from "./context/AppCopy";
// import UseState from "./useState/UseStateCounter";
// import UseReducerCounter from "./reducer/UseReducerCounter";
// import MultipleUseReducer from "./reducer/MultipleUseReducer";
// import AppCopy from "./reducer/AppCopy";
// import DataFetchingUseState from "./reducer/DataFetchingUseState";
// import DataFetchingUseReducer from "./reducer/DataFetchingUseReducer";
// import Parent from "./useCallback/Parent";
// import ClassTimer from './useRef Hook/ClassTimer';
// import HookTimer from "./useRef Hook/HookTimer";
// import DocTitleOne from "./Custom Hooks/DocTitleOne";
// import DocTitleTwo from "./Custom Hooks/DocTitleTwo";
// import CounterOne from "./Custom Hooks/CounterOne";
// import CounterTwo from "./Custom Hooks/CounterTwo";
// import List from "./List Rendering/List";
import Parent from "./memo/Parent";
import SideEffectClassComponent from "./useEffect/sideEffectClassComponent";
import ProblemWithoutCallbackInSetState from "./useEffect/problemWithoutCallbackInSetState";
import GetDerivedStateFromPropsParent from "./lifecycleMethods/getDerivedStateFromPropsParent";
// import RefsMemo from "./refs/RefsMemo";

// functional component /////////////////////////////////////////////////
// function App() {
//   // let name = "Khushboo Patel";
//   const [data, setData]=useState(0); // we are destructuring
//   function clickMe() {
//     // console.logMultipleUseReducer);
//   }
//   console.warn("--------------------");
//   return (
//     <div classNa me="App">
//       <h1>Hello { data}</h1>
//       <button onClick={clickMe}>Click Me!!</button>
//       {/* OR */}
//       {/* <button onClick={()=>alert("Button is clicked")}>Click Me!!</button> */}
//       {/* OR */}
//       {/* <button onClick={()=>clickMe()}>Click Me!!</button> */}
//     </div>
//   );
// }

// Class Component //////////////////////////////////////////
// function App() {
//   return (<ClassComponent/>)
// }

// props in functional component //////////////////////////////////////////
// function App(){
//   const [name, setName]=useState('Khushboo');
//   return(
//     <div className="App">
//       <h1>Props in React</h1>
//       <Student name={name}/>
//       <button onClick={()=>setName('Patel')}>Click me to show surname</button>
//     </div>
//   )
// }

// props in class component //////////////////////////////////////////
// class App extends Component {
//   constructor(){
//     super();
//     this.state={
//       name:"Khushboo",
//     }
//   }
//   render() {
//     return (
//       <div className="App">
//         <h1>Props in Class Component</h1>
//         <StudentClass name={this.state.name} />

//         <button onClick={()=>this.setState({name:"Patel"})}>Click me to show surname</button>
//       </div>
//     );
//   }
// }

// input box //////////////////////////////////////////
// function App() {
//   const[data, setData]=useState(null);
//   const[print, printData]=useState(false);

//   function getData(val) {
//     // this is how you get value of a input box
//     console.log(val.target.value);
//     setData(val.target.value);
//   }
//   return (
//     <div>
//       <center>
//         {
//           print?<h1>{data}</h1>: null
//         }

//         <input style={{ marginTop: 20 }} type="text" onChange={getData} />
//         <button onClick={printData}>Print Data</button>
//       </center>
//     </div>
//   );
// }

// app function //////////////////////////////////////////
function app() {
  // const [name, setName] = useState("pupu");

  // // for passing function as prop
  // function getdata() {
  //   console.log("I am a function in App");
  // }
  return (
    <div>
      {/* <MyUseState/>
       <Toggle/> */}
       {/* <Form/> */}
       {/* <ConditionalRendering/> */}
       {/* <Validation/> */}
      {/* <FunctionAsProp data={getdata}/>
      <FunctionAsProp2 data={getdata}/> */}
      {/* <RenderExample name={name}/> */}
      {/* <button onClick={()=>{setName('Patel')}}AppCopy
      {/* <ComponentUnmount/> */}
      {/* <Hooks/> */}
      {/* <UseEffect/> */}
      {/* <PropParent/> */}
      {/* <LifeCycle/> */}
      {/* <UseEffect/> */}
      {/* <MyBootStrap/> */}
      {/* <ReactRouter/> */}
      {/* <AppCopy/> */}
      {/* <UseState/> */}
      {/* <UseReducerCounter/> */}
      {/* <UseReducerComplex/> */}
      {/* <MultipleUseReducer/> */}
      {/* <DataFetchingUseState/> */}
      {/* <DataFetchingUseReducer/> */}
      {/* <Parent/> */}
      {/* <ClassTimer/>
      <HookTimer/> */}
      {/* <DocTitleOne/>
      <DocTitleTwo/> */}
      {/* <CounterOne/>
      <CounterTwo/> */}
      {/* <List/> */}
      {/* <ParentComponent/> */}
      {/* <Parent/> */}
      {/* <RefsMemo/> */}
      {/* <ClickCounter/>
      <HoverCounter/>  */}
      {/* <PortalDemo/> */}
      {/* <AppCopy/> */}
      {/* <FRInputRefParent/> */}
      {/* <SideEffectClassComponent/> */}
      <GetDerivedStateFromPropsParent/>
      {/* <ProblemWithoutCallbackInSetState/> */}
    </div>
  );
}
export default app;

// about constructor ////////////////////////////////////////
// export default class App extends Component {
//   constructor(){
//     super();

//     console.log("constructor");
//     this.state={
//       name:"Khushboo",
//     }
//   }
//   render() {
//     return (
//       <div>
//         <center>
//           <h1>{console.log("render", this.state.name)}</h1>
//         </center>
//       </div>
//     );
//   }
// }

/* 

> this means constructor is called before render
> ab kya nahi karna chahie hame constructor me - API call
  why??
  API call hame karna chahie componentDidMount me 
  iske liye event loop padho pehle
*/

/*
QUESTION
> why do we call super in constructor
> why do we prefer functional component over class component 
> jaise class component me state pehle set ho jati hai before the HTML is loaded. to kya aisa functional component me bhi hota hai kya?
*/
