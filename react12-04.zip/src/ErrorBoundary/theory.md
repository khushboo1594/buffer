A component goes through 4 phases in a life cycle -
1. mounting
2. updating
3. unmounting
4. error

# Error phase
It has 2 methods -
1. static getDerivedStateFromError(error)
2. componentDidCatch(error, info) 

# Need of Error boundaries
If there is a run-time error react unmounts the whole component. This is not a good user experience.    

# What would be great if we could do it
If we could catch the error anywhere in the component and make a fallback UI.

# What is Error boundary?
It is a component that implements either one or both lifecycle methods - getDerivedStateFromError or componentDidCatch becomes an error boundary. It is like catch but for components.

# getDerivedStateFromError
It is a static method which renders a fallback UI when an error is thrown. 

# componentDidCatch
It is a method which is used for logging the error information. 
It is redundant as errors are already logged in the console. 

# How to use it?
It is not a good practise to wrap a bunch of components in error boundary. Imagine a e-commerce website which has 1000's of product so will it be good if for any reason one of the product has some problem it will not be a good thing to not display rest of the products. So wrap every single component in error boundary rather than creating a bunch.

# When to use it?
It catches error during life cycle methods, constructor and rendering. 
It does not catches error inside 
- event handlers
- error inside error boundary
- asynchronous code
- server side rendering 
For these you have to use regular try and catch.

## NOTE:
Only class components can be error boundary component. Though it can be applied to any component whether functional or class

# Why not to use try-catch block
Because try-catch is good for imperative code like - 
try {
  showButton();
} catch (error) {
  // ...
}

But it is not good for declarative code like -
<Button />
