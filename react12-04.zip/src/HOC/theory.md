# Why do we need HOC?
The need to share common functionality between components

# What is HOC?
It a function which takes a component as argument and returns a new component.
In simple words, it will look something like this -
enhancedComponent = HOC(originalComponent)

# Naming convention
- the name of the file should start with - "with" 