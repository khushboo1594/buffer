import React, { PureComponent } from "react";
import PureComponentExample from "./PureComponentExample";
import RegularComponent from "./RegularComponent";

// agar hum parent component ko hi pure component bana denge then kuch bhi re-render nahi hoga dubara unless there is a difference
class ParentComponent extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      name: "Khushboo",
    };
  }
  componentDidMount() {
    setInterval(() => {
      this.setState({ name: "Khushboo" });
    }, 2000);
  }
  render() {
    console.log(
      "*************************Parent Component Render*************************"
    );
    return (
      <div>
        ParentComponent
        <PureComponentExample name={this.state.name} />
        <RegularComponent name={this.state.name} />
      </div>
    );
  }
}

export default ParentComponent;
