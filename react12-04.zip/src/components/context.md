# what is context API?

<!-- ![Alt text](./practise/src/Screenshot from 2022-03-30 14-42-32.png "Optional Title") -->

Context API provides a way to pass data through the component tree without having to pass props down manually through at every level.

# How context API was used before useContext hook?

# Steps

1. create context in the app component
   const userContext = React.createContext();
2. to provide this context with a value. The provider must wrap the children for the value to be available.
3. import it in the children where you want the value to be available.

# How to use the context API with the useContext hook?

2 steps are the same, it's just that the consumption is made simpler. > STEPS: 1. import useContext from react, import the context 2. pass the imported context as argument to useContext, it will return the context's value.

# Left to learn

1. how to consume mulitple conetexts? (https://youtu.be/tEqNSOhCHLU?list=PLC3y8-rFHvwisvxhZ135pogtX7_Oe3Q3A&t=223 )
2. In this video he has used terminology render props pattern what is that?
