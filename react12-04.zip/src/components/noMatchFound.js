import React from 'react'

function NoMatchFound() {
  return (
    <div>Page Not Found</div>
  )
}

export default NoMatchFound