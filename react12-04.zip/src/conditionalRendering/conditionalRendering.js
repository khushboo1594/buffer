import React, { useState } from "react";

export default function ConditionalRendering() {
  const [loggedIn, setLoggedIn] = useState(false);

  // Element variables /////////////////////////////////////////////////////////
  // let message;
  // if (loggedIn) {
  //   message = "Welcome Khushboo";
  // } else {
  //   message = "Welcome Guest";
  // }

  // return <div>{message}</div>;

  // Ternary operator /////////////////////////////////////////////////////////
  // return (
  //   <div>
  //     <center>{loggedIn ? "Welcome Khushboo" : "Welcome Guest"}</center>
  //   </div>
  // );

  // Short circuit operator /////////////////////////////////////////////////////
  // Left hand side is evaluated and if it is true then only the right hand code is executed otherwise not.
  return (
    loggedIn && (
      <div>
        <center>Welcome Khushboo</center>
      </div>
    )
  );

  // if-else ////////////////////////////////////////////////////////////////////
  // if (loggedIn) {
  //   return (
  //     <div>
  //       <center>
  //         <h1>Conditional Rendering</h1>
  //         <div>
  //           <h2>Welcome Khushboo</h2>
  //         </div>
  //       </center>
  //     </div>
  //   );
  // } else {
  //   return (
  //     <div>
  //       <center>
  //         <h1>Conditional Rendering</h1>
  //         <div>
  //           <h2>Welcome Guest</h2>
  //         </div>
  //       </center>
  //     </div>
  //   );
  // }

  //   if more than one condition
  // return (
  //   <div>
  //     <center>
  //       <h1>Conditional Rendering</h1>
  //       {loggedIn == 1 ? (
  //         <h2>Welcome User 1</h2>
  //       ) : loggedIn == 2 ? (
  //         <h2>Welcome User 2</h2>
  //       ) : (
  //         <h2>Welcome User 3</h2>
  //       )}
  //     </center>
  //   </div>
  // );
}
