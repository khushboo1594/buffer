# 4 ways:

1. if/ else
   The problem with if-else is there is a lot of repetition of the whole JSX code as we can't write if-else within the JSX.
2. element variables
   This a better approach to if-else
3. Ternary operator (recommended)
   This is a lot better than the the other 2 as we can write it inside the JSX. We usually follow this approach.
4. Short circuit operator (recommended)
   This is like ternary operator only. You use this when you want to return something or nothing.

Last 2 are more cleaner and easy to read than the first two.

# Short circuit in JS
Two important aspects of logical operators in JavaScript is that they evaluate from left to right, and they short-circuit.
> Logical OR
true || true;
// true
true || false;
// true
false || false;
// false
true || ****
// true
true && "dog"
// returns "dog"
[] && "dog"
// returns "dog"

What this means is that when JavaScript evaluates an OR expression, if the first operand is true, JavaScript with short-circuit and not even look at the second operand. In the example the asterisks (****) indicate any value — it simply doesn’t matter what it is as JavaScript will never even read that side of the Logical OR.

> Logical AND
In JavaScript, the logical AND operator will return true if both operands are true. It returns false in any other scenario. Here are a few simple examples:
If the first object is truthy, the logical AND operator returns the second operand.
If the first object is falsy, it returns that object

true && true
// true
true && false
// false
false && false
// false
false && "dog"
// ↪ false
0 && "dog"
// ↪ 0

There are two important aspects of logical operators inJavaScript that you should know:
They evaluate from left to right
They short-circuit
Short circuiting means that in JavaScript when we are evaluating an AND expression (&&), if the first operand is false, JavaScript will short-circuit and not even look at the second operand.
In other words — for the second operand in a logical AND expression to even be looked at, the first operand must be true. This allows us to do some pretty cool stuff with logical AND.

# falsy values
if (false)
if (null)
if (undefined)
if (0)
if (-0)
if (0n)
if (NaN)
if ("")