import React, { useState } from "react";

export default function Form() {
  const [name, setName] = useState("");
  const [tnc, setTnc] = useState("false");
  const [interest, setInterest] = useState("");
  const [inputDisable, setinputDisable] = useState(false);

  function getFormData(e) {
    e.preventDefault();
    console.log("first", name, tnc, interest);
  }
  return (
    <div>
      <center>
        <h1>Form handling1</h1>
        <form onSubmit={getFormData}>
          {/* <input type="text" placeholder="Enter Name" disabled="true" onChange={(e)=>setName(e.target.value)}/> */}
          <input
            type="text"
            placeholder="Enter Name"
            disabled={inputDisable}
            onChange={(e) => setName(e.target.value)}
          />
          <select onChange={(e) => setInterest(e.target.value)}>
            <option>Select Movies Names</option>
            <option>Troy</option>
            <option>Tamasha</option>
            <option>Aligarh</option>
            <option>Trapped</option>
            <option>Arth</option>
          </select>
          <br />
          <br />
          <input
            type="checkbox"
            onChange={(e) => setInterest(e.target.checked)}
          />
          <span>Accept Terms and Conditions</span>
          <br />
          <br />
          <button type="submit">Submit</button>
          <button onClick={() => setinputDisable(!inputDisable)}>
            Disable Input
          </button>
        </form>
      </center>
    </div>
  );
}

// React me hum single page application banate hai, usme application kbhi refresh nahi hoti. But submit par click karne par ho raha hai. To uske liye kya kare?
// > Uske liye hum preventDefault() use karte hai
