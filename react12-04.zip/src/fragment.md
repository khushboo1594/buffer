# What is a fragment
Fragment is used to wrap the JSX if we are returning multiple elements.

***Use <React.Fragment></React.Fragment> or <Fragment></Fragment> or <></>(this is a shorter syntax of declaring it)***

***There is only one prop that can be passed to fragment and that is key (<React.Fragment key={item.id}>). However the shorter syntax(<></>) does not support key.***

# Usage
Fragment use karne par DOM me extra node nahi banti hai

