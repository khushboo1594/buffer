import React, { Component } from "react";

export default class ComponentMount extends Component {
  constructor() {
    super();
    console.log("constructor");
    this.state = {
      name: "khushboo",
    };
  }
  componentDidMount() {
    console.log("componentDidMount");
  }
  render() {
    console.log("render");
    // this.setState({ name: "pupu" });
    /*   
    this line will cause error. we don't set state in render. now hum to kahenge k hum to button k click par state update kar rahe hai. to wo button k event se bind hai not with render.
    render me hum state islie update nahi karte because state update hone par it will get called aur hum uske andar bhi state hi update kar rahe hai to it will cause render to be called again aur infinite loop ban jaega aise. 
    agar hame aise kuch karwana hai jo state update hone par hum karwana chahte hai to hame to component did update me karwana chahie. 
    */

    return (
      <div>
        <h1>Component Did Mount</h1>
        <h1>{this.state.name}</h1>
        <button
          onClick={() => {
            this.setState({ name: "deepu" });
          }}
        >
          Click
        </button>
      </div>
    );
  }
}

/*
> componentDidMount() ko prop/ state update hone se koi farak nahi padta hai

> sequence of functions being called in life cycle method are -> constructor - render - componentDidMount

> when prop/ state is updated only render gets called again

> what do we do in componentDidMount?
    > API calls because it gets called only once and we don't want to so the API call again and again
    > hide/ show
    > anything related to HTML, DOM

> difference between componentDidMount and componentDidUpdate - componentDidUpdate is called when prop/ state is updated. 
*/
