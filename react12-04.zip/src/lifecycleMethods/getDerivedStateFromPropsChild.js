import React, { Component } from "react";

export class GetDerivedStateFromPropsChild extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
    };
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    // console.log("getDerivedStateFromProps");
    if (nextProps.name != prevState.name) {
      return { name: nextProps.name };
    } else {
      return null;
    }
  }
  render() {
    return <div>{this.state.name}</div>;
  }
}

export default GetDerivedStateFromPropsChild;
