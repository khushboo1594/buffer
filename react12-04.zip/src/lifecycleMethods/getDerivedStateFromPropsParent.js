import React, { Component } from "react";
import GetDerivedStateFromPropsChild from "./getDerivedStateFromPropsChild";
 
export class GetDerivedStateFromPropsParent extends Component {
  
  render() {
    return <div>
      <GetDerivedStateFromPropsChild name="Khushboo"/>
    </div>;
  }
}

export default GetDerivedStateFromPropsParent;
