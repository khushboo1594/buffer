**every lifecycle method is called by itself. we don't have to call it expilicitly. when, we do call, we overwrite them** 

# getDerivedStateFromProps(prop, state) : used rarely, deprecated
it is called right before  the first render and the subsequent updates. it should return a new state to update and null to update nothing. 
it exists for the cases when the state's value depend on the changes in the prop over time