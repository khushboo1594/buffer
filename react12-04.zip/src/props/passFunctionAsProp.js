// function as prop use karne ka fayda ye hai ki hum parent component me koi functonality bana kar har child component me use kar sakte hai, if we want.

import React from "react";

export default function FunctionAsProp(props) {
  return (
    <div>
      <center>
        <h1>Function passed as Prop</h1>
        {/* <button onClick={()=>props.data()}>Click me to see the prop!!</button> */}
        <button onClick={props.data}>Click me to see the prop!!</button>
        {/* both are valid */}
      </center>
    </div>
  );
}
 