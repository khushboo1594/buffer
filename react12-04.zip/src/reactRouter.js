// code evolution
// Why use React Router?
// React Router, and dynamic, client-side routing, allows us to build a single-page web application with navigation without the page refreshing as the user navigates.

// First step is to connect the URL in the browser with our react application. For that we need to use <BrowserRouter></BrowserRouter> with which we need to wrap our entire app component.

// Isme nested route se video baki hai

import React from "react";
import { Routes, Route } from "react-router-dom";
import About from "./components/about";
import Home from "./components/home";
import Navbar from "./components/navbar";
import NoMatchFound from "./components/noMatchFound";
import OrderSummary from "./components/orderSummary";

function ReactRouter() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="order---Summary" element={<OrderSummary />} />
        <Route path="*" element={<NoMatchFound />} />
      </Routes>
    </div>
  );
}

export default ReactRouter;
 