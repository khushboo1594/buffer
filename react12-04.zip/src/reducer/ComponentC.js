import React from "react";
import ComponentE from "./ComponentE";

function ComponentC() {
  return (
    <div>
      <ComponentE />
    </div>
  );
}

export default ComponentC;

    