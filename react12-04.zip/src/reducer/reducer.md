# What?
It is hook that is used for state managment[state?] in react.
But we already have useState for state managment, then why this? What's the difference?
    useState was made from useReducer only. This brings us to the next question then when to use which? 

> Points to remember
    > reduce function takes 2 arguments (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/Reduce)
        > reducer function
            this function itselft accepts 2 parameters and returns single value:
                > previousValue/ accumulator
                > current value
        > the initial value which it can use

# reduce vs useReducer
            *REDUCE*                                                  *USEREDUCER*
array.reduce(reducer, initialValue)                     .useReducer(reducer, initialState)

single value = reducer(previousValue, currentValue)     new state = reducer(currentState, action)

returns a single value                                  returns a pair of values [newState, dispatch] (dispatch is a method. It is basically used to specify the action)

# useReducer changes the state  

# Steps for using a useReducer hook
 1. useReducer hook is a function
 2. It takes 2 arguments
    > reducer function
       this function itselft accepts 2 parameters and returns single value:
                > current state
                > action 
                    use switch case
    > initialState
3. Define both of them outside the component

# What are the advantages of using state and action as an object with useReducer?
We can maintain both state and action as object.
1. By using action as a object we can pass multiple values to the reducer 
    Example: we can specify by how much we want to increment or decrement the counter by
2. By using state as an object we can keep track of multiple state variables.

This approach is helpful when dealing with global state. Here we are dealing with local state. We have different approach when we are dealing with local state.

# Problem: In the UseReducerComplex example we had to make 2 more switch cases even when we wanted to do the same thing as earlier cases
> Solution: multiple useReducer hooks
When you want to maintain multiple states in a single component and state trasition is also same then use multiple useReducer and use the same reducer function. This also makes things easier and helps in preventing duplicate code in reducer. 

# useReducer with useContext
> useReducer - local state managment
> useReducer with useContext - global state managment

# STEPS for useReducer with useContext
1. Implementing the counter in AppCopy through useReducer. Create context in AppCopy. Providing the count value and dispatch method to the context provider.
2. Conumse the context in the reqired component.

# Why?

# useState vs useReducer
                                            **useState**                                            **useReducer**
> Type of state:                        Number, String, Boolean                                Object/ Array
> No. of state transitions:             one/two                                                Too many
> Related state transitions:            No                                                     Yes
> Business logic:                       No business logic                                      Complex business logic
> Local vs Global:                      Local                                                  Global

##### TO-DO:
Implement useContext with props

### NOTE:
> Hooks are always used inside a component.

# Can useState change the state?