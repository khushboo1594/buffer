import React, { Component } from "react";

class RefsMemo extends Component {
  constructor(props) {
    super(props);

    // ref created with createRef
    this.inputRef = React.createRef();

    // callback ref
    this.cbRef = null;
    this.setcbRef = (element) => {
      this.cbRef = element;
    };
  }
  componentDidMount() {
    // using create Ref
    // this.inputRef.current.focus();
    // console.log(this.inputRef); // this.inputRef points to a object called current. It is the current object which points to the actual DOM node.

    // using call back ref
    /*
React calls the callback ref with the element as soon as the component mounts and calls callback ref with null when the component unmounts. That is why it is really important to check that whether the refernce is null or not.
    */
    if (this.cbRef) {
      this.cbRef.focus();
    }
  }
  clickHandler = () => {
    alert(this.inputRef.current.value);
  };
  render() {
    return (
      <div>
        <input type="text" ref={this.inputRef} />
        <button onClick={this.clickHandler}>Click</button>
        <input type="text" ref={this.setcbRef} />
      </div>
    );
  }
}

export default RefsMemo;
