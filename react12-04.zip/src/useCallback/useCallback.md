# When to useMemo and useCallback
https://kentcdodds.com/blog/usememo-and-usecallback

# Prob. with current scenerio:             ///////////////////////////////////
As we can see in the log that on updating either of the state everything(title, both the counts, both the buttons) is re-rendered again. Since this is a very small piece of code this is not causing any performance issue but if there were  30-40 components that were re-rendered again then this would have lead to a performance issue. The sol. to this is React.memo.

# React.memo                           /////////////////////
React.memo is a HOC which prevents a component from re-rendering if its prop/ state has not been changed.
It has nothing to do with hooks.

> How to use it?
Wrap the exported component into React.memo(). 
Example: export default React.memo(Button).

On using React.memo -
Rendering Age
Rendering button -  Increment Age
Rendering button -  Increment Salary
As you can see Increment Salary button is still being called and the same happens for Increment Age button.

Reason - in button component function is passed as prop. Everytime there is a new function call and because of referencial equality(https://youtu.be/IL82CzlaCys?list=PLC3y8-rFHvwisvxhZ135pogtX7_Oe3Q3A&t=652) being false it assumes that the component's prop has changed and it re-renders it. Same happens for Increment Age button.  

How to fix this?
useCallback - it is a hook that will change return a memoized version of the callback function that only changes if one of the dependenies has changed.

Why it is useful?
It is useful when passing callbacks to optimizied child components that rely on reference equality to prevent unnecessary renders. 

useCallback Hook parameters:
1. callback function
2. array of dependencies

**callback function**
jo function referencial equality k karan baar baar call ho raha tha waha callback function use karenge
