import React, { Component } from "react";

export class ProblemWithoutCallbackInSetState extends Component {
  constructor() {
    super();

    this.state = {
      count: 0,
    };
  }

  incrementCount() {
    console.log("incrementCount");
    // Note: this will *not* work as intended.
    // this.setState({ count: this.state.count + 1 });
    this.setState((state)=>{ count: this.state.count + 1 });

  }

  handleSomething() {
    // Let's say `this.state.count` starts at 0.
    console.log("handleSomething");
    this.incrementCount();
    this.incrementCount();
    this.incrementCount();
    // When React re-renders the component, `this.state.count` will be 1, but you expected 3.

    // This is because `incrementCount()` function above reads from `this.state.count`,
    // but React doesn't update `this.state.count` until the component is re-rendered.
    // So `incrementCount()` ends up reading `this.state.count` as 0 every time, and sets it to 1.

    // The fix is described below!
  }

  render() {
    return (
      <div>
        Count - {this.state.count}
        <button onClick={ this.handleSomething}>Increment by 3</button>
      </div>
    );
  }
}

export default ProblemWithoutCallbackInSetState;

// why the code is not working

// it is similar to useState/useStateCounter