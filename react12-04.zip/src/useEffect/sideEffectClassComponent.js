import React, { Component, useState, useEffect } from "react";

// updating the document title on click of a button in a class component ///////////////////////////////////////////////////

// we want to update the document title on the click of a button in a class component
// export class SideEffectClassComponent extends Component {
//   constructor() {
//     super();
//     // bina super k you cannot have a constructor. but ha bina props k chalega as you are not using props.

//     this.state = {
//       counter: 0,
//     };
//   }

//   // componentDidMount hame yaha call karna pad raha hai because when the component mounts we want to set the document title to the counter value
//   componentDidMount() {
//     document.title = this.state.counter;
//   }

//   // componentDidUpdate hame yaha call karna pad raha hai because when the component updates we want to set the document title to the counter value
//   componentDidUpdate() {
//     document.title = this.state.counter;
//   }

//   render() {
//     return (
//       <div>
//         {/* updating the count normally */}
//         {/* <button onClick={()=>this.setState({ counter: this.state.counter + 1 })}> */}

//         {/* wrong */}
//         {/* <button onClick={()=>this.setState({ counter: counter + 1 })}> */}
//         {/* state set karte samay counter:this.state.counter + 1 hoga na k counter:counter + 1  */}

//         {/* how setState is asynchronous? read this : https://reactjs.org/docs/faq-state.html#why-is-setstate-giving-me-the-wrong-value */}

//         {/* yaha ek chiz karke dekho make a callback function to access prev. state. for this, read this : https://reactjs.org/docs/faq-state.html#what-is-the-difference-between-passing-an-object-or-a-function-in-setstate
//         when you want to acess the current state follow this approach. and i think k hame hamesha hi yahi approach follow karni chahiye taki kbhi koi error aane ki gunjaish hi na rahe. now problem kya hoti hai if not using this approach for that refer to
//         */}
//         <button
//           onClick={
//             () =>
//               this.setState((state) => {
//                 // Important: read `state` instead of `this.state` when updating.
//                 return { counter: state.counter + 1 };
//               })

//               // this is also valid - https://reactjs.org/docs/react-component.html#setstate
//             // this.setState((state, props) => {
//             //   return {counter: state.counter + props.step};
//             // });
//           }
//         >
//           Count - {this.state.counter}
//         </button>
//       </div>
//     );
//   }
// }

// export default SideEffectClassComponent;

// class component me prob hi yahi thi k although we are doing the same thing in componentDidMount and componentDidUpdate since we have 2 differrent methods we have to do this this problem was solved using hooks in functional components.

// updating the document title on click of a button in a functional component //////////////////////////////////////////////

function SideEffectClassComponent() {
  const [count, setCount] = useState(0);
  useEffect(() => (document.title = count));
  return (
    <div>
      <button onClick={() => setCount(count + 1)}>Clicked {count} times</button>
    </div>
  );
}

export default SideEffectClassComponent;
