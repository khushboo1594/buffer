import React, { Component } from 'react'

export class ClassTimer extends Component {
    interval;
    constructor(props) {
        super(props);
        this.state = {
            counter: 0,
        }
    }

    componentDidMount() {
        this.interval = setInterval(() => {
            this.setState({ counter: this.state.counter + 1})
        }, 1000);
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    render() {
        return (
            <div>
                <h1>Counter - {this.state.counter}</h1><br />
                <button onClick={()=>clearInterval(this.interval)}>Clear Timer</button>
          {/* {
              setInterval(() => {
                  this.setState({counter:this.state.counter+1})
              }, 1000)
          }  */}
          {/* Why this is behaving wierd??? */}
            </div>
        )
    }
}

export default ClassTimer;


