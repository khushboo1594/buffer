import React, { useState } from "react";

function UseState() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
  };
  const decrement = () => {
    setCount(count - 1);
  };
  const reset = () => {
    setCount(0);
  };
  const incrementFive=()=>{
    // this is not working and we know the reason why
    // for (let index = 0; index < 5; index++) {
    //   setCount(count+1);
    // }
    for (let index = 0; index < 5; index++) {
      setCount((prevState)=>prevState+1);
    }
  }
  return (
    <div>
      <center>
        Example of useState
        <h1>{count}</h1>
        {/* <button onClick={increment}>Press to Increment</button>
        <button onClick={decrement}>Press to Decrement</button>
        <button onClick={reset}>Press to Reset</button> */}
        {/* Yaha par arrow function q nahi banaya onClick par? arrow function banane par counter increment hi nahi ho raha hai*/}
        {/* because increment already arrow function hai. we are passing function to onclick not making a funtion call that is why we are not putting paranthesis after function name */}
        {/* you can do it like this also, but this is not safe. why???*/}
        {/* <button onClick={() => setCount(count + 1)}>Press to Increment</button>
        <button onClick={() => setCount(count - 1)}>Press to Decrement</button>
        <button onClick={() => setCount(0)}>Press to Reset</button> */}
        {/* whenever you want to update the state based on the previous state call a function that has access to prev state and then only update the state. let's understand it by an example. */}
        <button onClick={() => setCount(count + 1)}>Press to Increment</button>
        <button onClick={() => setCount(count - 1)}>Press to Decrement</button>
        <button onClick={() => setCount(0)}>Press to Reset</button>
        <button onClick={incrementFive}>Increment 5</button>
        {/* here instead of directly updating the state by 5 we have made a loop. now why this is not  working because it does not have access to the prevState value that is why we should always update the state based on the previous state call a function that has access to prev state and then only update the state*/}
        {/* onclick par hamesha arrow function call hota hai. chunki hum yaha koi function call nahi kar rahe hai we have to make a arrow function here.   */}
      </center>
    </div>
  );
}

export default UseState;
