const redux= require('redux');
const createStore = redux.createStore
const applyMiddleWare= redux.applyMiddleware
const thunkMiddleWare = require('redux-thunk').default
const axios = require('axios')


const initialstate = {
  loading: true,
  users: [],
  error: "",
};

const FETCH_USERS_REQUEST = "FETCH_USERS_REQUEST";
const FETCH_USERS_SUCCESS = "FETCH_USERS_SUCCESS";
const FETCH_USERS_FAILED = "FETCH_USERS_FAILED";

const fetchUsersRequest = ()=> {
  return {
    type: FETCH_USERS_REQUEST,
  };
}

const fetchUsersSuccess =(users) => {
  return {
    type: FETCH_USERS_SUCCESS,
    payload: users,
  };
}

const  fetchUsersFailed = (error)=> {
  return {
    type: FETCH_USERS_FAILED,
    payload: error
  };
}


const reducer = (state  = initialstate , action )=>{
    switch (action.type) {
        case FETCH_USERS_REQUEST:
            return {
                ...state,
                loading: true
            }
        case FETCH_USERS_SUCCESS:
            return {
                loading: false ,
                users: action.payload,
                error: ''
            }            
        case FETCH_USERS_FAILED :
            return {
                loading: false,
                users: [],
                error: action.payload
            }
             
    }
}

const fetchUser =()=>{
    return  function(dispatch) {
        dispatch(fetchUsersRequest())
        axios.get('https://jsonplaceholdr.typicode.com/users').then(res =>{
            //res.data
            const users = res.data.map(user => user.id)
            dispatch(fetchUsersSuccess(users))
        }).catch(err =>{
            // err.message
            dispatch(fetchUsersFailed(err.message))
        })
    }
}

const store = createStore(reducer,applyMiddleWare(thunkMiddleWare));
store.subscribe(()=> {console.log(store.getState())})
store.dispatch(fetchUser())
