cakeReducer 0
cakeReducer 1
icecreamReducer 2
icecreamReducer 3
cakeReducer 4
icecreamReducer 5
buyCake 6
cakeReducer 7
icecreamReducer 8
 action BUY_CAKE @ 16:02:00.186
   prev state { cake: { numberOfCakes: 10 }, icecream: { numberOfIcecreams: 20 } }
   action     { type: 'BUY_CAKE', info: 6 }
   next state { cake: { numberOfCakes: 9 }, icecream: { numberOfIcecreams: 20 } }
buyCake 9
cakeReducer 10
icecreamReducer 11
 action BUY_CAKE @ 16:02:00.198
   prev state { cake: { numberOfCakes: 9 }, icecream: { numberOfIcecreams: 20 } }
   action     { type: 'BUY_CAKE', info: 9 }
   next state { cake: { numberOfCakes: 8 }, icecream: { numberOfIcecreams: 20 } }
buyCake 12
cakeReducer 13
icecreamReducer 14
 action BUY_CAKE @ 16:02:00.201
   prev state { cake: { numberOfCakes: 8 }, icecream: { numberOfIcecreams: 20 } }
   action     { type: 'BUY_CAKE', info: 12 }
   next state { cake: { numberOfCakes: 7 }, icecream: { numberOfIcecreams: 20 } }
buyIcecream 15
cakeReducer 16
icecreamReducer 17
 action BUY_ICECREAM @ 16:02:00.203
   prev state { cake: { numberOfCakes: 7 }, icecream: { numberOfIcecreams: 20 } }
   action     { type: 'BUY_ICECREAM', info: 15 }
   next state { cake: { numberOfCakes: 7 }, icecream: { numberOfIcecreams: 19 } }
buyIcecream 18
cakeReducer 19
icecreamReducer 20
 action BUY_ICECREAM @ 16:02:00.204
   prev state { cake: { numberOfCakes: 7 }, icecream: { numberOfIcecreams: 19 } }
   action     { type: 'BUY_ICECREAM', info: 18 }
   next state { cake: { numberOfCakes: 7 }, icecream: { numberOfIcecreams: 18 } }